package com.example.tema2_db.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.example.tema2_db.model.Student;

import java.util.List;

public class StudentAdapter extends RecyclerView.Adapter<StudentAdapter.MyViewHolder> {
    private List<Student> students;

    public static class MyViewHolder extends RecyclerView.ViewHolder{
        public TextView studentFullName, studentMark;

        public MyViewHolder(View view) {
            super(view);
            this.studentView = studentView;
        }
    }

    public StudentAdapter(List<Student> students){
        this.students = students;
    }

    public List<Student> getStudents() {
        return students;
    }

    public void setStudents(List<Student> students) {
        this.students = students;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        TextView studentView = (TextView) LayoutInflater
                .from(parent.getContext())
                .inflate(R.layout.student_view, parent, false);
        MyViewHolder mvh = new MyViewHolder(studentView);
        return mvh;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        TextView textView = holder.studentView.findViewById(R.id.holder_info_text_name);
        Student user = students.get(position);
        String cardText = "id:" + String.valueOf(user.id) + " name:" + user.fullName + " mark:" + String.valueOf(user.mark);
        textView.setText(cardText);
    }

    @Override
    public int getItemCount() {
        return students.size();
    }
}
